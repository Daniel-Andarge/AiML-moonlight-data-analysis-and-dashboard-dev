"""MoonLight package

This is the MoonLight package. It contains modules and sub-packages for the MoonLight project.
"""

__version__ = "1.0.0"